/**
 * Created by kiran on 7/15/2015.
 */
/*Learn controller Syntax*/
/*step 1 module
  step 2 controller with a name
  step 3 scope
 */

angular.module("eMart")
       .controller("headerCtrl", function($scope){
               $scope.welcome="Hello Guys Welcome To angularjs."
               $scope.selectAllEmail=function() {

               }
            });
